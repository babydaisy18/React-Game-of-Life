"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
// CIS 197 - React HW

var x = 48;
var y = 36;
var cells = Array.apply(null, Array(x * y)).map(function () {
    return false;
});

exports.x = x;
exports.y = y;
exports.cells = cells;